// Zoho Catalyst - bridgex Function (Node.js)
// Simple API Bridge - No external dependencies

module.exports = (req, res) => {
    // CORS Headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Handle preflight
    if (req.method === 'OPTIONS') {
        res.status(200).send('OK');
        return;
    }

    // Return test data for now
    res.status(200).json({
        status: 'success',
        source: 'catalyst_bridge',
        timestamp: new Date().toISOString(),
        records: [
            { ID: '1', Asset_ID: 'BW-LIVE-001', Item_Name: 'Live Asset Test', Category: 'IT Equipment', Status: 'Active' }
        ]
    });
};